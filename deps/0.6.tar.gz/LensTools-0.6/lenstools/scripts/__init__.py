"""
Command line scripts that come with lenstools

"""