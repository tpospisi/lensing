int min_int(int i,int j){
	
	if(i<j){
		return i;
	}
	else{
		return j;
	}
}

int max_int(int i,int j){

	if(i>j) return i;
	else return j;

}

long min_long(long i,long j){
	
	if(i<j){
		return i;
	}
	else{
		return j;
	}
}