Ray tracing simulations
***********************

.. _notebook:  http://nbviewer.ipython.org/github/apetri/Notebooks/blob/master/gravitational_lensing.ipynb

lenstools provides an implementation of the multi--lens--plane algorithm. For a hands-on demo of the current capabilities of the ray tracer, please look at this notebook_