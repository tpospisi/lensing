Gallery
*******

.. toctree::
	:maxdepth: 2

	examples/power_spectrum
	examples/power_spectrum_mpi
	examples/parallel_operations
	examples/histograms
	examples/gaussian_random_field
	examples/catalog_to_map
	examples/eb_decomposition
	examples/design
	examples/gadget_io
	examples/confidence_contours