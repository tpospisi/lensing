3D Visualization gallery
========================

This is the code underlying a 3D gallery produced with the kick-ass [mayavi2](http://docs.enthought.com/mayavi/mayavi/index.html) data visualization engine