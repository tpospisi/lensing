Welcome to LensTools!
+++++++++++++++++++++

.. image:: http://img.shields.io/pypi/dm/lenstools.svg?style=flat
        :target: https://pypi.python.org/pypi/lenstools/
.. image:: http://img.shields.io/pypi/v/lenstools.svg?style=flat
        :target: https://pypi.python.org/pypi/lenstools/
.. image:: http://img.shields.io/badge/license-MIT-blue.svg?style=flat
        :target: https://github.com/apetri/LensTools/blob/master/licenses/LICENSE.rst
.. image:: https://readthedocs.org/projects/lenstools/badge/?version=latest
		:target: http://lenstools.readthedocs.org/en/latest/?badge=latest
		:alt: Documentation Status

This python package collects together a suite of widely used analysis tools in Weak Gravitational Lensing. For more information visit `the project official page <http://lenstools.readthedocs.org>`_
